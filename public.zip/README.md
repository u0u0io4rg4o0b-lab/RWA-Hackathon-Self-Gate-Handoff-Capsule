RWA Self Proof Demo

這個專案示範一個簡化版的 RWA（Real World Assets）驗證流程。它分為兩個部分：

後端 (functions/)，提供兩個 HTTP 端點：

rpcHealthCheck：連接到區塊鏈 RPC 服務並回傳最新區塊高度。

verifyProof：接受使用者提供的 proof 資料和要求條件，返回驗證結果（此示例總是通過驗證）。

前端 (public/)，提供一組簡單頁面用於展示區塊鏈應用流程以及提交 proof 與產生日誌。

安裝

確保使用 Node.js 20 版本，可使用 .nvmrc 協助管理版本。

進入 functions 目錄安裝依賴並進行型別檢查：

cd functions
npm install

# 如果需要實際部署到 Firebase，請自行安裝 firebase-functions firebase-admin 等套件

npm run typecheck

將 functions/env.example 複製為 .env，並填入以下環境變數：

CELO_RPC_ENDPOINT：Celo RPC 節點位址，用於區塊高度查詢。

NETWORK_NAME：隨意用於標示環境的名稱。

ALLOWED_ORIGINS：允許前端跨域存取的來源。

如果要本地測試後端，建議使用 Firebase Emulator 或 Node 的相容框架。此示範未提供伺服器啟動腳本，僅匯出函式。

使用前端

在任意靜態伺服器開啟 public/ 目錄，如：

npx http-server public -p 8080

瀏覽器訪問 http://localhost:8080/self-gate.html 可測試 proof 驗證流程。輸入 proof JSON 並送出後，會向後端 verifyProof 端點發送請求。成功後會在瀏覽器的 localStorage 中追加兩筆日誌：

TERMS_HASHED：代表條款文字的雜湊（此範例使用預設字串）。

PROOF_ACCEPTED：代表 proof 的雜湊。

其他頁面（如 anchor.html、bylaws.html 等）則展示文件雜湊、章程建議、會議紀錄等功能雛型。

授權與第三方依賴

本專案使用的第三方套件包含 TypeScript、Firebase Functions 等，它們均採用 MIT 或 Apache 2.0 等自由授權。專案自身程式碼採 MIT 授權，可自由修改與再利用。請注意，實際整合區塊鏈或隱私驗證時，應遵守相關協議與軟體授權。
